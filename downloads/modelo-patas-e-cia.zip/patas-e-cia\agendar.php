<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Agendar — Patas &amp; Cia</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="faixa">Hoje é 01/01/2025 · Seg a Sáb, 8h às 18h · (11) 4002-8922</div>

  <header class="topo">
    <div class="container topo-linha">
      <a class="logo" href="index.php"><span class="logo-marca">P</span>Patas &amp; Cia</a>
      <button class="menu-btn" type="button" aria-label="Abrir menu">Menu</button>
      <nav class="menu">
        <a href="index.php">Início</a>
        <a href="servicos.php">Serviços</a>
        <a href="agendar.php">Agendar</a>
        <a href="contato.php">Contato</a>
        <a href="atendimento.php">Atendimento</a>
        <a href="login.php" class="menu-admin">Área restrita</a>
      </nav>
    </div>
  </header>

  <main class="container secao">
    <h1>Agendar horário</h1>

    <!-- MODELOS DE AVISO: use quando precisar (etapas 4, 5, 9 e 10)

    <div class="alerta sucesso">
      Agendamento de <strong>NOME DO PET</strong> confirmado para DD/MM/AAAA às HH:MM.
      <a class="btn btn-whats" href="https://wa.me/5511940028922?text=MENSAGEM" target="_blank">Confirmar pelo WhatsApp</a>
    </div>

    <div class="alerta erro">
      <ul>
        <li>Mensagem de erro</li>
      </ul>
    </div>
    -->

    <!-- Formulário 1: escolher o dia (envia por GET para esta mesma página) -->
    <form class="cartao" method="get" action="agendar.php">
      <h2>1. Escolha o dia</h2>
      <div class="linha-dia">
        <label>Data <input type="date" name="data" value=""></label>
        <button class="btn secundario" type="submit">Ver horários</button>
      </div>
    </form>

    <!-- Formulário 2: horário e dados (envia por POST para esta mesma página).
         Sem o atributo "required" de propósito: quem valida é o PHP (etapa 5). -->
    <form class="cartao" method="post" action="agendar.php">
      <!-- o dia escolhido no formulário 1 viaja escondido neste campo -->
      <input type="hidden" name="data" value="">

      <h2>2. Escolha o horário</h2>
      <!-- Os horários vão das 08:00 às 17:00, de hora em hora (etapa 2).
           Horário já reservado recebe a classe "ocupado" e o atributo disabled (etapa 9). -->
      <div class="horarios">
        <label class="horario"><input type="radio" name="horario" value="08:00"> 08:00</label>
        <label class="horario"><input type="radio" name="horario" value="09:00"> 09:00</label>
        <label class="horario ocupado"><input type="radio" name="horario" value="10:00" disabled> 10:00</label>
      </div>

      <h2>3. Seus dados</h2>
      <div class="campos">
        <label>Seu nome <input type="text" name="tutor" value=""></label>
        <label>Telefone (WhatsApp) <input type="tel" name="telefone" value="" placeholder="(11) 99999-9999"></label>
        <label>Nome do pet <input type="text" name="pet" value=""></label>
        <label>Serviço
          <!-- As opções devem vir do array $servicos (etapa 3) -->
          <select name="servico">
            <option value="">Selecione...</option>
            <option>Banho</option>
            <option>Tosa higiênica</option>
          </select>
        </label>
      </div>
      <button class="btn" type="submit">Confirmar agendamento</button>
    </form>
  </main>

  <footer class="rodape">
    <div class="container">
      <p><strong>Patas &amp; Cia</strong> · Rua das Flores, 120 · São Paulo/SP · (11) 4002-8922</p>
      <p>&copy; 2024 Patas &amp; Cia. Todos os direitos reservados.</p>
    </div>
  </footer>
  <script src="script.js"></script>
</body>
</html>
