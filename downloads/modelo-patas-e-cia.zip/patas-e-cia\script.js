// =========================================
// Patas & Cia — JavaScript do site (pronto)
// Roda no NAVEGADOR, depois que o PHP já montou a página.
// =========================================

// Menu no celular: abre e fecha a lista de links
const botaoMenu = document.querySelector('.menu-btn');
const menu = document.querySelector('.menu');
if (botaoMenu && menu) {
  botaoMenu.addEventListener('click', () => menu.classList.toggle('aberto'));
}

// Destaca no menu o link da página atual
const paginaAtual = location.pathname.split('/').pop() || 'index.php';
document.querySelectorAll('.menu a').forEach((link) => {
  if (link.getAttribute('href') === paginaAtual) link.style.fontWeight = '700';
});

// Chat: rola até a última mensagem
const chat = document.getElementById('chat');
if (chat) chat.scrollTop = chat.scrollHeight;

// Máscara simples de telefone: (11) 99999-9999
const tel = document.querySelector('input[name="telefone"]');
if (tel) {
  tel.addEventListener('input', () => {
    const n = tel.value.replace(/\D/g, '').slice(0, 11);
    let t = n;
    if (n.length > 2) t = '(' + n.slice(0, 2) + ') ' + n.slice(2);
    if (n.length > 7) t = '(' + n.slice(0, 2) + ') ' + n.slice(2, n.length - 4) + '-' + n.slice(-4);
    tel.value = t;
  });
}
