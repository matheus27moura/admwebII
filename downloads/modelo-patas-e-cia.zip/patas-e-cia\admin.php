<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Painel — Patas &amp; Cia</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="faixa">Hoje é 01/01/2025 · Seg a Sáb, 8h às 18h · (11) 4002-8922</div>

  <header class="topo">
    <div class="container topo-linha">
      <a class="logo" href="index.php"><span class="logo-marca">P</span>Patas &amp; Cia</a>
      <button class="menu-btn" type="button" aria-label="Abrir menu">Menu</button>
      <nav class="menu">
        <a href="index.php">Início</a>
        <a href="servicos.php">Serviços</a>
        <a href="agendar.php">Agendar</a>
        <a href="contato.php">Contato</a>
        <a href="atendimento.php">Atendimento</a>
        <a href="login.php" class="menu-admin">Área restrita</a>
      </nav>
    </div>
  </header>

  <!-- Só quem fez login pode ver esta página (etapa 7) -->
  <main class="container secao">
    <div class="painel-topo">
      <h1>Olá, Administrador</h1>
      <a class="btn secundario" href="sair.php">Sair</a>
    </div>

    <div class="numeros">
      <div><strong>2</strong><span>agendamentos</span></div>
      <div><strong>0</strong><span>para hoje</span></div>
      <div><strong>1</strong><span>mensagens</span></div>
    </div>

    <h2>Agendamentos</h2>
    <!-- As linhas vêm de dados/agendamentos.json (etapa 7), em ordem de data e hora (etapa 9) -->
    <table class="tabela agendamentos">
      <thead><tr><th>Data</th><th>Hora</th><th>Pet</th><th>Serviço</th><th>Tutor</th><th>Telefone</th></tr></thead>
      <tbody>
        <tr><td>20/11/2025</td><td>09:00</td><td>Thor</td><td>Banho</td><td>Mariana</td><td>11999998888</td></tr>
        <tr><td>21/11/2025</td><td>14:00</td><td>Luna</td><td>Vacinação</td><td>Carlos</td><td>11988887777</td></tr>
      </tbody>
    </table>

    <h2>Mensagens</h2>
    <!-- As linhas vêm de dados/mensagens.json (etapa 7) -->
    <table class="tabela mensagens">
      <thead><tr><th>Data</th><th>Nome</th><th>E-mail</th><th>Assunto</th><th>Mensagem</th></tr></thead>
      <tbody>
        <tr><td>19/11/2025 10:32</td><td>Beatriz</td><td>bia@email.com</td><td>Dúvida</td><td>Vocês aceitam gatos no hotelzinho?</td></tr>
      </tbody>
    </table>
  </main>

  <footer class="rodape">
    <div class="container">
      <p><strong>Patas &amp; Cia</strong> · Rua das Flores, 120 · São Paulo/SP · (11) 4002-8922</p>
      <p>&copy; 2024 Patas &amp; Cia. Todos os direitos reservados.</p>
    </div>
  </footer>
  <script src="script.js"></script>
</body>
</html>
