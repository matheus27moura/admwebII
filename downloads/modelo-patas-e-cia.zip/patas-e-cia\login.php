<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Área restrita — Patas &amp; Cia</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="faixa">Hoje é 01/01/2025 · Seg a Sáb, 8h às 18h · (11) 4002-8922</div>

  <header class="topo">
    <div class="container topo-linha">
      <a class="logo" href="index.php"><span class="logo-marca">P</span>Patas &amp; Cia</a>
      <button class="menu-btn" type="button" aria-label="Abrir menu">Menu</button>
      <nav class="menu">
        <a href="index.php">Início</a>
        <a href="servicos.php">Serviços</a>
        <a href="agendar.php">Agendar</a>
        <a href="contato.php">Contato</a>
        <a href="atendimento.php">Atendimento</a>
        <a href="login.php" class="menu-admin">Área restrita</a>
      </nav>
    </div>
  </header>

  <main class="container secao estreito">
    <h1>Área restrita</h1>
    <p class="muted">Acesso exclusivo da equipe da Patas &amp; Cia.</p>

    <!-- Se o login falhar (etapa 7):
    <div class="alerta erro">E-mail ou senha incorretos.</div>
    -->

    <form class="cartao" method="post" action="login.php">
      <label>E-mail <input type="text" name="email" value=""></label>
      <label>Senha <input type="password" name="senha"></label>
      <button class="btn" type="submit">Entrar</button>
    </form>
  </main>

  <footer class="rodape">
    <div class="container">
      <p><strong>Patas &amp; Cia</strong> · Rua das Flores, 120 · São Paulo/SP · (11) 4002-8922</p>
      <p>&copy; 2024 Patas &amp; Cia. Todos os direitos reservados.</p>
    </div>
  </footer>
  <script src="script.js"></script>
</body>
</html>
