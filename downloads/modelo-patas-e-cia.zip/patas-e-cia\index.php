<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Patas &amp; Cia — Pet shop e clínica</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <!-- Faixa de informações: a data deve ser a de HOJE (etapa 1) -->
  <div class="faixa">Hoje é 01/01/2025 · Seg a Sáb, 8h às 18h · (11) 4002-8922</div>

  <header class="topo">
    <div class="container topo-linha">
      <a class="logo" href="index.php"><span class="logo-marca">P</span>Patas &amp; Cia</a>
      <button class="menu-btn" type="button" aria-label="Abrir menu">Menu</button>
      <nav class="menu">
        <a href="index.php">Início</a>
        <a href="servicos.php">Serviços</a>
        <a href="agendar.php">Agendar</a>
        <a href="contato.php">Contato</a>
        <a href="atendimento.php">Atendimento</a>
        <a href="login.php" class="menu-admin">Área restrita</a>
      </nav>
    </div>
  </header>

  <main>
    <section class="hero">
      <div class="container">
        <!-- O selo muda conforme o horário de funcionamento (etapa 2) -->
        <span class="selo aberto">Aberto agora</span>
        <!-- A saudação muda conforme a hora do dia (etapa 2) -->
        <h1>Bom dia! Seu pet merece cuidado de verdade.</h1>
        <p>Banho, tosa, consultas e hospedagem com muito carinho, em São Paulo.</p>
        <a class="btn" href="agendar.php">Agendar horário</a>
        <!-- Temperatura real vinda de uma API de clima (etapa 8) -->
        <p class="clima">Agora em São Paulo: -- °C</p>
      </div>
    </section>

    <section class="container secao">
      <!-- O número de anos deve ser CALCULADO a partir do ano de fundação (etapa 1) -->
      <p class="destaque-anos">Fundada em 2015 — há <strong>10 anos</strong> cuidando de pets.</p>
    </section>

    <section class="container secao">
      <h2>Serviços em destaque</h2>
      <!-- Os 3 primeiros serviços do array (etapa 3) -->
      <div class="grade">
        <article class="servico">
          <span class="categoria">Higiene</span>
          <h3>Banho</h3>
          <p>Shampoo neutro, secagem e perfume suave.</p>
          <p class="preco">R$ 45,00</p>
        </article>
        <article class="servico">
          <span class="categoria">Higiene</span>
          <h3>Tosa higiênica</h3>
          <p>Aparo de patas, barriga e região íntima.</p>
          <p class="preco">R$ 35,00</p>
        </article>
        <article class="servico">
          <span class="categoria">Higiene</span>
          <h3>Banho e tosa completa</h3>
          <p>Banho completo com tosa na tesoura ou máquina.</p>
          <p class="preco">R$ 90,00</p>
        </article>
      </div>
      <p><a href="servicos.php">Ver todos os serviços &rarr;</a></p>
    </section>
  </main>

  <footer class="rodape">
    <div class="container">
      <p><strong>Patas &amp; Cia</strong> · Rua das Flores, 120 · São Paulo/SP · (11) 4002-8922</p>
      <!-- O ano deve ser sempre o ano atual (etapa 1) -->
      <p>&copy; 2024 Patas &amp; Cia. Todos os direitos reservados.</p>
    </div>
  </footer>
  <script src="script.js"></script>
</body>
</html>
