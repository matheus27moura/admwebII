<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Atendimento — Patas &amp; Cia</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="faixa">Hoje é 01/01/2025 · Seg a Sáb, 8h às 18h · (11) 4002-8922</div>

  <header class="topo">
    <div class="container topo-linha">
      <a class="logo" href="index.php"><span class="logo-marca">P</span>Patas &amp; Cia</a>
      <button class="menu-btn" type="button" aria-label="Abrir menu">Menu</button>
      <nav class="menu">
        <a href="index.php">Início</a>
        <a href="servicos.php">Serviços</a>
        <a href="agendar.php">Agendar</a>
        <a href="contato.php">Contato</a>
        <a href="atendimento.php">Atendimento</a>
        <a href="login.php" class="menu-admin">Área restrita</a>
      </nav>
    </div>
  </header>

  <main class="container secao estreito">
    <h1>Atendimento virtual</h1>
    <p class="muted">Converse com a Mel, nossa assistente. Ela responde na hora.</p>

    <!-- As mensagens vêm da sessão do visitante (etapa 10).
         "bot" = resposta da Mel, "cliente" = o que o visitante digitou. -->
    <div class="chat" id="chat">
      <div class="msg bot">Olá! Eu sou a Mel, assistente virtual da Patas &amp; Cia. Digite:<br>1 - Horários<br>2 - Preços<br>3 - Endereço<br>4 - Agendar</div>
      <div class="msg cliente">2</div>
      <div class="msg bot">Nossos preços:<br>Banho: R$ 45,00<br>Tosa higiênica: R$ 35,00</div>
    </div>

    <form class="chat-form" method="post" action="atendimento.php">
      <input type="text" name="mensagem" placeholder="Digite sua mensagem..." autocomplete="off">
      <button class="btn" type="submit">Enviar</button>
    </form>
    <p><a href="atendimento.php?limpar=1">Começar nova conversa</a></p>
  </main>

  <footer class="rodape">
    <div class="container">
      <p><strong>Patas &amp; Cia</strong> · Rua das Flores, 120 · São Paulo/SP · (11) 4002-8922</p>
      <p>&copy; 2024 Patas &amp; Cia. Todos os direitos reservados.</p>
    </div>
  </footer>
  <script src="script.js"></script>
</body>
</html>
