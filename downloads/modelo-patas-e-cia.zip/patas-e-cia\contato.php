<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Contato — Patas &amp; Cia</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="faixa">Hoje é 01/01/2025 · Seg a Sáb, 8h às 18h · (11) 4002-8922</div>

  <header class="topo">
    <div class="container topo-linha">
      <a class="logo" href="index.php"><span class="logo-marca">P</span>Patas &amp; Cia</a>
      <button class="menu-btn" type="button" aria-label="Abrir menu">Menu</button>
      <nav class="menu">
        <a href="index.php">Início</a>
        <a href="servicos.php">Serviços</a>
        <a href="agendar.php">Agendar</a>
        <a href="contato.php">Contato</a>
        <a href="atendimento.php">Atendimento</a>
        <a href="login.php" class="menu-admin">Área restrita</a>
      </nav>
    </div>
  </header>

  <main class="container secao">
    <h1>Fale conosco</h1>

    <!-- MODELOS DE AVISO (etapas 4 e 5):
    <div class="alerta sucesso">Obrigado, NOME! Respondemos em até 1 dia útil.</div>
    <div class="alerta erro"><ul><li>Mensagem de erro</li></ul></div>
    -->

    <div class="colunas">
      <!-- Mensagem: envia por POST para esta mesma página -->
      <form class="cartao" method="post" action="contato.php">
        <h2>Envie uma mensagem</h2>
        <label>Nome <input type="text" name="nome" value=""></label>
        <label>E-mail <input type="text" name="email" value=""></label>
        <label>Assunto
          <select name="assunto">
            <option>Dúvida</option>
            <option>Orçamento</option>
            <option>Elogio</option>
            <option>Reclamação</option>
          </select>
        </label>
        <label>Mensagem <textarea name="mensagem" rows="5"></textarea></label>
        <button class="btn" type="submit">Enviar mensagem</button>
      </form>

      <!-- Leva e traz: consulta o CEP numa API (etapa 8) -->
      <form class="cartao" method="get" action="contato.php">
        <h2>Leva e traz</h2>
        <p class="muted">Buscamos seu pet em casa. Digite o CEP para conferir o endereço.</p>
        <div class="linha-dia">
          <label>CEP <input type="text" name="cep" value="" placeholder="00000-000"></label>
          <button class="btn secundario" type="submit">Buscar endereço</button>
        </div>
        <!-- Se o CEP não existir: <p class="alerta erro">CEP não encontrado.</p> -->
        <label>Rua <input type="text" name="rua" value="" readonly></label>
        <label>Bairro <input type="text" name="bairro" value="" readonly></label>
        <label>Cidade <input type="text" name="cidade" value="" readonly></label>
      </form>
    </div>
  </main>

  <footer class="rodape">
    <div class="container">
      <p><strong>Patas &amp; Cia</strong> · Rua das Flores, 120 · São Paulo/SP · (11) 4002-8922</p>
      <p>&copy; 2024 Patas &amp; Cia. Todos os direitos reservados.</p>
    </div>
  </footer>
  <script src="script.js"></script>
</body>
</html>
