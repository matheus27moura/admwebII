<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Serviços — Patas &amp; Cia</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="faixa">Hoje é 01/01/2025 · Seg a Sáb, 8h às 18h · (11) 4002-8922</div>

  <header class="topo">
    <div class="container topo-linha">
      <a class="logo" href="index.php"><span class="logo-marca">P</span>Patas &amp; Cia</a>
      <button class="menu-btn" type="button" aria-label="Abrir menu">Menu</button>
      <nav class="menu">
        <a href="index.php">Início</a>
        <a href="servicos.php">Serviços</a>
        <a href="agendar.php">Agendar</a>
        <a href="contato.php">Contato</a>
        <a href="atendimento.php">Atendimento</a>
        <a href="login.php" class="menu-admin">Área restrita</a>
      </nav>
    </div>
  </header>

  <main class="container secao">
    <h1>Nossos serviços</h1>

    <!-- Busca por nome e filtro por categoria (etapa 4) -->
    <form class="busca" method="get" action="servicos.php">
      <input type="search" name="busca" placeholder="Buscar serviço (ex.: banho)" value="">
      <select name="categoria">
        <option value="">Todas as categorias</option>
        <option>Higiene</option>
        <option>Saúde</option>
        <option>Hospedagem</option>
      </select>
      <button class="btn" type="submit">Buscar</button>
    </form>

    <p class="resultado">6 serviço(s) encontrado(s)</p>

    <!-- Quando nada for encontrado, mostre no lugar da grade (etapa 4):
         <p class="vazio">Nenhum serviço encontrado. Tente outra palavra.</p> -->

    <!-- Estes 6 cartões devem vir do array $servicos (etapa 3) -->
    <div class="grade">
      <article class="servico">
        <span class="categoria">Higiene</span>
        <h3>Banho</h3>
        <p>Shampoo neutro, secagem e perfume suave.</p>
        <p class="preco">R$ 45,00</p>
      </article>
      <article class="servico">
        <span class="categoria">Higiene</span>
        <h3>Tosa higiênica</h3>
        <p>Aparo de patas, barriga e região íntima.</p>
        <p class="preco">R$ 35,00</p>
      </article>
      <article class="servico">
        <span class="categoria">Higiene</span>
        <h3>Banho e tosa completa</h3>
        <p>Banho completo com tosa na tesoura ou máquina.</p>
        <p class="preco">R$ 90,00</p>
      </article>
      <article class="servico">
        <span class="categoria">Saúde</span>
        <h3>Consulta veterinária</h3>
        <p>Avaliação completa com médica veterinária.</p>
        <p class="preco">R$ 150,00</p>
      </article>
      <article class="servico">
        <span class="categoria">Saúde</span>
        <h3>Vacinação</h3>
        <p>Vacinas importadas com carteirinha digital.</p>
        <p class="preco">R$ 80,00</p>
      </article>
      <article class="servico">
        <span class="categoria">Hospedagem</span>
        <h3>Hotelzinho (diária)</h3>
        <p>Espaço climatizado, passeios e câmeras ao vivo.</p>
        <p class="preco">R$ 70,00</p>
      </article>
    </div>
  </main>

  <footer class="rodape">
    <div class="container">
      <p><strong>Patas &amp; Cia</strong> · Rua das Flores, 120 · São Paulo/SP · (11) 4002-8922</p>
      <p>&copy; 2024 Patas &amp; Cia. Todos os direitos reservados.</p>
    </div>
  </footer>
  <script src="script.js"></script>
</body>
</html>
